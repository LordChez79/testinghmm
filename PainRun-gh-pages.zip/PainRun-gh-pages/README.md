Pain Run 3D
===========

*A bad (but ad-free!) copy of Death Run 3D... and in VR!*

<a href="https://gfwilliams.github.io/PainRun/">Try it!</a>

Either:

* Use the arrow keys to move into the correct location
* Click the screen in the left to go left, right for right, etc.
* Use a gamepad (A,B,X,Y)
* In VR, look in the direction you want to go.


Created by [Gordon Williams](https://github.com/gfwilliams) for [JSOxford Game Dev Day 2016](http://jsoxford.com/)
